create function factorial(n decimal(3))
  returns decimal(20)
  BEGIN
    DECLARE factorial DECIMAL(20, 0) DEFAULT 1;
    DECLARE counter DECIMAL(3, 0);
    SET counter = n;
    factorial_loop : REPEAT
      SET factorial = factorial * counter;
      SET counter = counter - 1;
    UNTIL counter = 1
    END REPEAT;
    RETURN factorial;
  END;

